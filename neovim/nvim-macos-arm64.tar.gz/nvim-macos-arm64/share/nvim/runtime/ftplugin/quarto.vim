runtime ftplugin/rmd.vim
